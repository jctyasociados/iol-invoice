#!/data/data/com.termux/files/usr/bin/bash
export APP_SETTINGS='config.ProductionConfig'
export APP_MAIL_USERNAME_SENDER='iolenterprises.inc.usa.2021@gmail.com'
export APP_MAIL_USERNAME='iolenterprises.inc.usa.2021@gmail.com'
export APP_MAIL_PASSWORD='dwnyvqirnpquhdzk'
export RECAPTCHA_KEY='6LeNcKQdAAAAAG4aXnkS_5r-9GxJtFL5FDTTAlDt'
export SECRET_KEY_RECAPTCHA='6LeNcKQdAAAAAAgqEUS8DQnF4Vlsq61HvALJE6o5'
export DROPBOX_TOKEN=''
export DATABASE_URL='postgresql://iol-invoice-main-db-0e38cc74b0d0f741a:TH7SHaHuyqDY4Q61VvKQnGbJ8YP9RP@user-prod-us-east-2-1.cluster-cfi5vnucvv3w.us-east-2.rds.amazonaws.com:5432/iol-invoice-main-db-0e38cc74b0d0f741a'
export APP_SECRET_KEY='1jeR45Tyhu7ueso54dfgTREaqlpcftqi'
export APP_SECURITY_PASSWORD_SALT='qkirTy524DesqoiuGtyHj678GtfE123'


#elephant:
  
#export DATABASE_URL='postgresql://dpqvrbwj:09_WimPab2vf2AJclGwgZ7ku2edoNzdj@queenie.db.elephantsql.com/dpqvrbwj'
